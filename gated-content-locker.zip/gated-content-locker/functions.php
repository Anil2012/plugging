<?php

/* custom gtl plugin css admin */
// add_action( 'admin_init', 'gtl_assets' );
function gtl_assets() {
	wp_register_style( 'style-admin', plugins_url( 'assets/css/style-admin.css' , __FILE__ ) );
    wp_enqueue_style( 'style-admin' );    
}

/* custom gtl plugin css front*/
add_action( 'wp_enqueue_scripts', 'gtl_function_front' );
function gtl_function_front() {
      wp_enqueue_script( 'jquery' );
   wp_register_style( 'style-front', plugins_url( 'assets/css/style-front.css' , __FILE__ ) );
   wp_enqueue_style( 'style-front' );

   wp_register_script( 'validate-js', plugins_url( 'assets/js/jquery.validate.js' , __FILE__ ) );
   wp_enqueue_script( 'validate-js' );

   wp_register_script( 'printui-validation', plugins_url( 'assets/js/printui-validation.js' , __FILE__ ) );
   wp_enqueue_script( 'printui-validation' );

} 

// Hook to handle form submission
add_action('admin_post_handle_guest_form', 'handle_guest_form_submission');
add_action('admin_post_nopriv_handle_guest_form', 'handle_guest_form_submission');
 
function handle_guest_form_submission() {
    // Verify the nonce to secure the form
   
    if ( isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'guest_form_nonce') ) {
        // Process the form data here
        // echo '<pre>';
        // print_r($_POST);
        // die();
        $user_identifier = sanitize_text_field( $_POST['_wpnonce'] );
        //$blog_url = sanitize_text_field( $_POST['_wp_http_referer'] );
        $blog_url = sanitize_text_field( $_POST['blogurl'] );
        $name = sanitize_text_field( $_POST['name'] );
        $email = sanitize_text_field( $_POST['email'] );
        $mobile = sanitize_text_field( $_POST['mobile'] );
        $ip_address = sanitize_text_field( $_POST['ip_address'] );
        if (isset($user_identifier)) {
		       setcookie('user_identifier', $user_identifier, time() + 3600, '/');
               setcookie('ip_address', $ip_address, time() + 3600, '/');
		}
		
        // Process the form data here for database
     global $wpdb;
    $gcl_tableName = $wpdb->prefix . 'gcl_user';
 	$insert = $wpdb->insert($gcl_tableName,array(
                "user_identifier" => $user_identifier,
                "blog_url"	=> $blog_url,
                "name"  	=> $name ,
                "email"     => $email ,
                "mobile"    => $mobile,
                "ip_address" => $ip_address
            ));
 	    
 	    if($insert) {
 	    	$referer = wp_get_referer();
           if ($referer) {
			  wp_redirect($referer);
			    exit;
			} else {
			   wp_redirect(home_url('/'));
			    exit;
			}
 	    }
      
      } else {
        // Nonce verification failed
        wp_die('Security check failed.');
    }
}

// Function to add meta box
function custom_blog_description_meta_box() {
    add_meta_box(
        'custom-blog-description',
        'Custom Blog Description',
        'custom_blog_description_meta_box_callback',
        'post', 
        'normal',
        'high'
    );
}

// Callback function for meta box content
function custom_blog_description_meta_box_callback($post) {
    $description = get_post_meta($post->ID, '_custom_blog_description', true);

    wp_editor($description, 'custom_blog_description', array('textarea_name' => '_custom_blog_description'));
}

// Hook to add the meta box
add_action('add_meta_boxes', 'custom_blog_description_meta_box');

// Function to save meta box data
function save_custom_blog_description_meta_box_data($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (isset($_POST['_custom_blog_description'])) {
        $description = wp_kses_post($_POST['_custom_blog_description']);
        update_post_meta($post_id, '_custom_blog_description', $description);
    }
}

// Hook to save meta box data
add_action('save_post', 'save_custom_blog_description_meta_box_data');


// Function to add a form before or after the post content
function add_custom_form_to_content($content) {
    if (is_single()) {
        global $post;     
        global $wpdb;
                    $table = $wpdb->prefix . 'gcl_user';
                      
                      $current_url=get_permalink($post->ID);
                      if(isset($_COOKIE['user_identifier'])) { 

                    $results = $wpdb->get_results("SELECT * FROM " . $table . " WHERE user_identifier = '".$_COOKIE['user_identifier']."'AND ip_address = '".$_COOKIE['ip_address']."' AND blog_url = '".$current_url."' ");

                    }

                        if(!empty(get_post_meta($post->ID , '_custom_blog_description', true))) {
                        if(empty($results)) { 

                       $content = do_shortcode( get_post_meta($post->ID , '_custom_blog_description', true) );
                      
                        } else {
                          $content = get_the_content();
                        }
                      }else {
                          $content = get_the_content();
                        }


    }
    return $content;
}
add_filter('the_content', 'add_custom_form_to_content');




