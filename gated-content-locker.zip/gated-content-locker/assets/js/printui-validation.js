jQuery(document).ready(function($) { 
  $("#custom-contact-form").validate({
			rules: {
				email: {
				    required: true,
                    email: true
				},
				name: {
		          required: true
		        }
			},
			messages: {
				email: {
		          required: 'This is a required field.',
		          email: 'Please enter a valid Email Address.',
		        },
				 name: {
		          required: 'This is a required field.',
		        }
            }
		});

});