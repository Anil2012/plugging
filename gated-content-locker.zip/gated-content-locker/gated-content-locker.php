<?php
/*
Plugin Name: Gated Content Locker
Plugin URI: https://emorphis.com/
Description: Gated Content Locker for Blog
Author: Emorphis
Author URI: https://emorphis.com 
*/

if (!defined('ABSPATH')) {
    exit;
}

/* Add custome form and shortcode for blog*/

function custom_contact_form_shortcode() {
	 global $post;
	$form = "";
    // Check if the IP address is forwarded
if ( isset( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
    $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
} elseif ( isset( $_SERVER['HTTP_CLIENT_IP'] ) ) {
    $ip_address = $_SERVER['HTTP_CLIENT_IP'];
} else {
    $ip_address = $_SERVER['REMOTE_ADDR'];
}

// Check if the IP address is forwarded
if ( isset( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
    $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
} elseif ( isset( $_SERVER['HTTP_CLIENT_IP'] ) ) {
    $ip_address = $_SERVER['HTTP_CLIENT_IP'];
} else {
    $ip_address = $_SERVER['REMOTE_ADDR'];
}

// Output the IP address
// echo 'Your IP address is: ' . $ip_address;


$form .= '<form id="custom-contact-form" action="'.esc_url( admin_url('admin-post.php') ).'" method="post">';
$form .= wp_nonce_field('guest_form_nonce');
$form .= '<input type="hidden" name="ip_address" value="'.$ip_address.'">';
$form .= '<input type="hidden" name="action" value="handle_guest_form">';
$form .= '<div class="blog_dcl_form">';
$form .= '<div>';  
$form .= '<label for="name">Name:<span style="color:red">*</span></label>';
$form .= '<input type="text" name="name" class="form_input" >';
$form .= '</div>';
$form .= '<div>';
$form .= '<label for="email">Email:<span style="color:red">*</span></label>';
$form .= '<input type="email" name="email" class="form_input">';
$form .= '</div>';
$form .= '<div>';
$form .= '<label for="mobile">Mobile:</label>';
$form .= '<input name="mobile" class="form_input">';
$form .= '</div>';
$form .= '</div>';
$form .= '<input type="hidden" name="blogurl" value="'.get_permalink(get_the_ID()).'">';
$form .= '<input type="submit" class="contact_submit form_input" name="submit" value="Submit">';
$form .= '</form>';
return $form; ?>

<?php
}
add_shortcode('custom_contact_form', 'custom_contact_form_shortcode');

/* add file in pluging */
function gcl_functions_load() {
    require_once plugin_dir_path( __FILE__ ) . 'functions.php';   
    require_once plugin_dir_path( __FILE__ ) . 'userlist.php';  
}
add_action( 'init', 'gcl_functions_load' );


/* Create gcl_user table */
function create_gcl_user_table()
{      
  global $wpdb; 
  $gcl_user_table = $wpdb->prefix . 'gcl_user';
  $charset_collate = $wpdb->get_charset_collate();

 if($wpdb->get_var( "show tables like '$gcl_user_table'" ) != $gcl_user_table ) 
 {
       $sql1 = "CREATE TABLE $gcl_user_table (
                ID int(11) NOT NULL auto_increment,
                user_identifier varchar(200) DEFAULT NULL,
                blog_url varchar(200) DEFAULT NULL,
                name varchar(200) DEFAULT NULL,
                email varchar(200) DEFAULT NULL,
                mobile varchar(200) DEFAULT NULL,
                ip_address varchar(200) DEFAULT NULL,
                datetime datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (ID)
        ) $charset_collate;";

   require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
   dbDelta( $sql1 );
 }

}
register_activation_hook( __FILE__, 'create_gcl_user_table' );

